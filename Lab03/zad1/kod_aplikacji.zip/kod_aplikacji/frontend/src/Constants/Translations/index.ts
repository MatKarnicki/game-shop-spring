
export const LANGUAGES = [
    { label: "polish", code: "pl" },
    { label: "english", code: "us" },
    // {label: "ukrainian", code: "ua"},
];