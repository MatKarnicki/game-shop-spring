package engineering.app.enums;

public enum Role {
    USER,
    ADMIN
}
